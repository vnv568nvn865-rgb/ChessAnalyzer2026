# بناء APK

يتطلب البناء جهاز كمبيوتر عليه Android Studio أو Android SDK + Gradle.

من مجلد `android`:
`./gradlew assembleDebug`

سينتج عادة:
`app/build/outputs/apk/debug/app-debug.apk`

ملاحظة: هذه حزمة Android WebView للنسخة الأولية. النسخة النهائية الأفضل ستضمّن Stockfish محلياً بدلاً من CDN، وتستخدم تخزيناً محلياً للتحليلات، ثم تُوقّع Release APK.
