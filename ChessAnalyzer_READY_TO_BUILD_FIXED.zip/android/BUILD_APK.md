# بناء Chess Analyzer APK

هذا المشروع مجهز بحيث تكون مكتبة `chess.js` ومحرك `Stockfish 18 Lite Single` داخل التطبيق نفسه.

لا يحتاج المستخدم إلى تعديل ملفات `app` بعد البناء.

## البناء عبر GitHub Actions

1. ارفع محتويات هذا المشروع إلى مستودع GitHub.
2. افتح تبويب **Actions**.
3. اختر **Build Chess Analyzer APK**.
4. اضغط **Run workflow**.
5. بعد نجاح البناء، افتح نتيجة التشغيل ثم قسم **Artifacts** ونزّل `ChessAnalyzer-APK`.

أثناء البناء يتم تنزيل:

- `chess.js` الإصدار 1.4.0 ووضعه داخل `assets/vendor`.
- `Stockfish 18 Lite Single` وملف WASM الخاص به ووضعهما داخل `assets/vendor`.

وبذلك لا يعتمد التطبيق أثناء التشغيل على CDN لتحميل هذه المكتبات.

## ملاحظة

يحتاج التطبيق إلى الإنترنت فقط لجلب بيانات المباريات العامة من Chess.com. أما `chess.js` وStockfish فهما مضمّنان داخل APK.
