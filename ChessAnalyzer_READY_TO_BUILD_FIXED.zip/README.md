# ChessAnalyzer — Android ready-to-build

نسخة معدلة من المشروع لتجنب تحميل `chess.js` وStockfish من CDN أثناء تشغيل التطبيق.

GitHub Actions يقوم بتنزيل المكتبات أثناء البناء ويضمّنها داخل APK تلقائياً.
