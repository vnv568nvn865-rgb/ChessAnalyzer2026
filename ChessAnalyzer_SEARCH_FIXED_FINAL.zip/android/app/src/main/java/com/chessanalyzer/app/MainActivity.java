package com.chessanalyzer.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

public class MainActivity extends Activity {
    private WebView web;

    public static class ChessApiBridge {
        @JavascriptInterface
        public String getJson(String urlString) {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(urlString);
                if (!"https".equalsIgnoreCase(url.getProtocol()) ||
                        !"api.chess.com".equalsIgnoreCase(url.getHost())) {
                    return errorJson("عنوان API غير مسموح.");
                }

                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(20000);
                connection.setUseCaches(false);
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("User-Agent", "ChessAnalyzer/1.2 Android");

                int code = connection.getResponseCode();
                InputStream stream = code >= 200 && code < 300
                        ? connection.getInputStream() : connection.getErrorStream();
                if (stream == null) return errorJson("Chess.com API HTTP " + code);

                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(stream, StandardCharsets.UTF_8));
                StringBuilder body = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) body.append(line);
                reader.close();

                if (code < 200 || code >= 300) {
                    String message = "Chess.com API HTTP " + code;
                    try {
                        JSONObject obj = new JSONObject(body.toString());
                        if (obj.has("message")) message = obj.getString("message");
                    } catch (Exception ignored) {}
                    return errorJson(message);
                }

                return body.toString();
            } catch (Exception e) {
                return errorJson("تعذر الاتصال بـ Chess.com: " +
                        (e.getMessage() == null ? "خطأ في الشبكة" : e.getMessage()));
            } finally {
                if (connection != null) connection.disconnect();
            }
        }

        private String errorJson(String message) {
            try {
                JSONObject obj = new JSONObject();
                obj.put("__error", message);
                return obj.toString();
            } catch (Exception ignored) {
                return "{\"__error\":\"تعذر الاتصال بـ Chess.com.\"}";
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClientCompat() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new ChessApiBridge(), "AndroidChessApi");

        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
