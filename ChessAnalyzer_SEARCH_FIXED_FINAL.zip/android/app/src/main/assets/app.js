import { Chess } from "./vendor/chess.js";

const $ = id => document.getElementById(id);
const state = {
  username:"", games:[], selected:null, chess:null, ply:0, engine:null,
  analysis:[], analyzing:false, engineReady:false
};

const PIECES = {
  w:{p:"♙",n:"♘",b:"♗",r:"♖",q:"♕",k:"♔"},
  b:{p:"♟",n:"♞",b:"♝",r:"♜",q:"♛",k:"♚"}
};

$("playerForm").addEventListener("submit", async e=>{
  e.preventDefault();
  const username=$("username").value.trim();
  if(!username) return;
  state.username=username;
  $("status").textContent="جاري البحث عن المباريات…";
  try{
    state.games=await fetchRecentGames(username,Number($("gameCount").value));
    renderGames();
    updateStats();
    $("status").textContent=`تم العثور على ${state.games.length} مباراة.`;
  }catch(err){
    console.error("Chess.com search error:",err);
    $("status").textContent="تعذر جلب المباريات: "+(err?.message||"خطأ غير معروف");
    $("username").value=username;
  }
});

$("filter").addEventListener("change",renderGames);
["first","prev","next","last"].forEach(id=>$(id).addEventListener("click",()=>moveTo(id)));
$("analyzeBtn").addEventListener("click",analyzeCurrent);
$("themeBtn").addEventListener("click",()=>document.body.classList.toggle("light-mode"));

async function fetchJson(url){
  // Android WebView: use the native bridge so the Chess.com API request is
  // made by Android instead of a cross-origin fetch from an app asset.
  if(window.AndroidChessApi && typeof window.AndroidChessApi.getJson === "function") {
    const raw=window.AndroidChessApi.getJson(url);
    if(!raw) throw new Error("تعذر الاتصال بـ Chess.com. تحقق من الإنترنت ثم حاول مرة أخرى.");
    let data;
    try{ data=JSON.parse(raw); }
    catch{ throw new Error("استجابة غير صالحة من Chess.com."); }
    if(data && data.__error) throw new Error(data.__error);
    return data;
  }

  // Normal browser fallback.
  const r=await fetch(url,{
    method:"GET",
    cache:"no-store",
    headers:{"Accept":"application/json"}
  });
  if(!r.ok) throw new Error(`Chess.com API ${r.status}`);
  return await r.json();
}
async function fetchRecentGames(username,want){
  const base=`https://api.chess.com/pub/player/${encodeURIComponent(username)}`;
  const player=await fetchJson(base);
  if(player.username?.toLowerCase()!==username.toLowerCase()) throw new Error("المعرف غير موجود.");
  const archives=(await fetchJson(`${base}/games/archives`)).archives||[];
  const out=[];
  for(let i=archives.length-1;i>=0 && out.length<want;i--){
    const data=await fetchJson(archives[i]);
    for(const g of (data.games||[])){
      if(g.pgn && g.rules==="chess" && ["blitz","rapid","bullet","daily","classical"].includes(g.time_class)){
        out.push(g);
      }
    }
  }
  out.sort((a,b)=>(b.end_time||0)-(a.end_time||0));
  return out.slice(0,want);
}
function renderGames(){
  const filter=$("filter").value;
  $("games").innerHTML="";
  state.games.filter(g=>{
    const me=(g.white.username||"").toLowerCase()===state.username.toLowerCase();
    const result=me?g.white.result:g.black.result;
    return filter==="all" || (filter==="win"&&result==="win") || (filter==="loss"&&["loss","checkmated","timeout","resigned","abandoned"].includes(result)) || (filter==="draw"&&result==="agreed");
  }).forEach((g,i)=>{
    const el=document.createElement("div");
    el.className="game";
    const meWhite=(g.white.username||"").toLowerCase()===state.username.toLowerCase();
    const myResult=meWhite?g.white.result:g.black.result;
    const cls=myResult==="win"?"result-win":(["loss","checkmated","timeout","resigned","abandoned"].includes(myResult)?"result-loss":"result-draw");
    el.innerHTML=`<div class="players"><span>${esc(g.white.username)}</span><span>${esc(g.black.username)}</span></div>
      <small><b class="${cls}">${resultLabel(myResult)}</b> · ${g.time_class||"?"} · ${new Date((g.end_time||0)*1000).toLocaleString("ar")}</small>`;
    el.onclick=()=>selectGame(g,el);
    $("games").appendChild(el);
  });
}
function resultLabel(r){return r==="win"?"فوز":(["loss","checkmated","timeout","resigned","abandoned"].includes(r)?"خسارة":"تعادل")}
function esc(s=""){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function updateStats(){
  let w=0,d=0;
  for(const g of state.games){
    const meWhite=g.white.username.toLowerCase()===state.username.toLowerCase();
    const r=meWhite?g.white.result:g.black.result;
    if(r==="win")w++; else if(r==="agreed"||r==="stalemate"||r==="repetition"||r==="insufficient")d++;
  }
  $("sGames").textContent=state.games.length;
  $("sWins").textContent=w;
  $("sDraws").textContent=d;
  const acc=state.games.map(g=>g.accuracies?.[g.white.username.toLowerCase()===state.username.toLowerCase()?"white":"black"]).filter(x=>typeof x==="number");
  $("sAccuracy").textContent=acc.length?(acc.reduce((a,b)=>a+b,0)/acc.length).toFixed(1)+"%":"—";
}
function selectGame(g,el){
  document.querySelectorAll(".game").forEach(x=>x.classList.remove("active")); el.classList.add("active");
  state.selected=g; state.chess=new Chess(); state.ply=0; state.analysis=[]; state.analyzing=false;
  const w=g.white.username,b=g.black.username;
  $("gameTitle").textContent=`${w} × ${b}`;
  $("gameMeta").textContent=`${g.time_class||""} · ${g.white.rating||"?"} vs ${g.black.rating||"?"} · ${g.result||""}`;
  $("analyzeBtn").disabled=false;
  const moves=parsePgnMoves(g.pgn);
  state.moves=moves; renderBoard(); renderChart();
}
function parsePgnMoves(pgn){
  const c=new Chess();
  try{c.loadPgn(pgn,{sloppy:true});return c.history({verbose:true});}catch{
    const clean=pgn.split("\n\n").pop().replace(/\{[^}]*\}/g,"").replace(/\d+\.(\.\.)?/g,"").replace(/1-0|0-1|1\/2-1\/2|\*/g,"");
    const x=new Chess(); const arr=[];
    for(const token of clean.trim().split(/\s+/)){try{const m=x.move(token,{sloppy:true});if(m)arr.push(m)}catch{}}
    return arr;
  }
}
function positionAt(ply){
  const c=new Chess();
  for(let i=0;i<ply;i++) c.move(state.moves[i]);
  return c;
}
function renderBoard(){
  const c=positionAt(state.ply), board=c.board();
  $("board").innerHTML="";
  for(let r=0;r<8;r++)for(let f=0;f<8;f++){
    const sq=document.createElement("div"); sq.className=`sq ${(r+f)%2?"dark":"light"}`;
    const p=board[r][f];
    if(p){sq.textContent=PIECES[p.color][p.type];sq.classList.add(p.color==="w"?"piece-white":"piece-black")}
    $("board").appendChild(sq);
  }
  $("moveNumber").textContent=`${state.ply}/${state.moves?.length||0}`;
  const a=state.analysis[state.ply-1];
  if(a){$("bestMove").textContent=a.best||"—";$("depth").textContent=a.depth||"—";$("eval").textContent=formatCp(a.score)}
}
function moveTo(id){
  const n=state.moves?.length||0;
  if(id==="first")state.ply=0;
  if(id==="prev")state.ply=Math.max(0,state.ply-1);
  if(id==="next")state.ply=Math.min(n,state.ply+1);
  if(id==="last")state.ply=n;
  renderBoard();
}
function formatCp(cp){if(cp==null)return"—";return (cp/100).toFixed(2)}
function setEval(cp){
  const x=Math.max(-500,Math.min(500,cp||0));
  const pct=50+(x/10);
  $("evalFill").style.height=`${Math.max(5,Math.min(95,pct))}%`;
  $("evalText").textContent=formatCp(cp);
}
function initEngine(){
  if(state.engine) return state.engine;
  const workerUrl="./vendor/stockfish-18-lite-single.js";
  try{
    state.engine=new Worker(workerUrl);
  }catch(err){
    $("engineState").textContent="Stockfish: تعذر التشغيل";
    throw new Error("تعذر تشغيل Stockfish داخل WebView.");
  }
  state.engine.onmessage=e=>{
    const line=typeof e.data==="string"?e.data:"";
    if(line==="uciok"){state.engine.postMessage("isready");return}
    if(line==="readyok"){state.engineReady=true;$("engineState").textContent="Stockfish 18: جاهز";return}
    if(line.startsWith("info ") && line.includes(" score ")){
      const d=parseInfo(line); if(d){$("depth").textContent=d.depth||"—";setEval(d.score)}
    }
  };
  state.engine.postMessage("uci");
  return state.engine;
}
function parseInfo(line){
  const dm=line.match(/\bdepth (\d+)/), cm=line.match(/\bscore cp (-?\d+)/), mm=line.match(/\bscore mate (-?\d+)/), pv=line.match(/\bpv (.+)$/);
  return {depth:dm?+dm[1]:null,score:cm?+cm[1]:(mm?(+mm[1]>0?100000:-100000):null),pv:pv?pv[1]:""};
}
async function analyzeCurrent(){
  if(!state.selected||state.analyzing)return;
  const engine=initEngine(); state.analyzing=true; $("analyzeBtn").disabled=true;
  $("engineState").textContent="Stockfish 18: يحلل…";
  state.analysis=[];
  const total=state.moves.length;
  for(let i=0;i<total;i++){
    const c=positionAt(i), fen=c.fen();
    const result=await analyzePosition(engine,fen);
    state.analysis[i]=result;
    $("status").textContent=`تحليل ${i+1}/${total}`;
  }
  state.analyzing=false;$("analyzeBtn").disabled=false;
  $("engineState").textContent="Stockfish 18: اكتمل";
  renderChart(); summarize();
  renderBoard();
}
function analyzePosition(engine,fen){
  return new Promise(resolve=>{
    let best="",score=null,depth=0;
    const handler=e=>{
      const line=typeof e.data==="string"?e.data:"";
      if(line.startsWith("bestmove")){
        engine.removeEventListener("message",handler);
        resolve({best:best.split(" ")[0]||line.split(" ")[1]||"—",score,depth});
      }else if(line.startsWith("info ")){
        const d=parseInfo(line); if(d){if(d.score!=null)score=d.score;if(d.depth)depth=d.depth;if(d.pv)best=d.pv}
      }
    };
    engine.addEventListener("message",handler);
    engine.postMessage("stop");
    engine.postMessage(`position fen ${fen}`);
    engine.postMessage("go depth 14");
  });
}
function renderChart(){
  const vals=state.analysis.map(x=>x?.score).filter(x=>x!=null);
  if(!vals.length){$("chart").innerHTML='<div style="color:#6b7280">سيظهر الرسم بعد التحليل.</div>';return}
  const w=700,h=180,p=8,min=-500,max=500;
  const pts=vals.map((v,i)=>`${p+i*Math.max(1,(w-2*p)/Math.max(1,vals.length-1))},${h-p-((Math.max(min,Math.min(max,v))-min)/(max-min))*(h-2*p)}`).join(" ");
  $("chart").innerHTML=`<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><line x1="0" y1="${h/2}" x2="${w}" y2="${h/2}" stroke="#475569"/><polyline fill="none" stroke="#60a5fa" stroke-width="3" points="${pts}"/></svg>`;
}
function summarize(){
  const vals=state.analysis.map(x=>x?.score).filter(x=>x!=null);
  if(!vals.length)return;
  let swings=[];
  for(let i=1;i<vals.length;i++){const diff=Math.abs(vals[i]-vals[i-1]);if(diff>=100)swings.push({i,diff})}
  const big=swings.sort((a,b)=>b.diff-a.diff).slice(0,5);
  $("summary").innerHTML=`<h4>ملخص التحليل</h4><p>تم تحليل ${vals.length} وضعية بعمق 14. تم العثور على ${big.length} تغيّرات كبيرة في التقييم (≥ 1.00 بيدق). يمكنك التنقل بين النقلات لرؤية تقييم كل وضعية.</p>`;
}
initEngine();
